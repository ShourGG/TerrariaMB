const t="SUCCESS",a={tokenName:"Authorization",tokenValue:"yB_CH5MUwIuTV9d7a_XnSXCBrQVL63PmfA__"},s={status:200,msg:t,data:a};export{s as a};
