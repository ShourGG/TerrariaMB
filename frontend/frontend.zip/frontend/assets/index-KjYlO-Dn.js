import{_ as e,e as c,i as s}from"./index-_hVn5I9W.js";const t={},n={class:"p-4px"};function o(r,_){return s(),c("div",n,"工作台")}const i=e(t,[["render",o]]);export{i as default};
